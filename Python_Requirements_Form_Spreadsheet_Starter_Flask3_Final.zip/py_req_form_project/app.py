from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)
DB_PATH = "requirements.db"

def init_db():
    """Create the SQLite table if it does not already exist."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS requirements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                requirements_id TEXT NOT NULL,
                date TEXT NOT NULL,
                description TEXT NOT NULL,
                spearhead TEXT NOT NULL,
                stakeholder TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
        """)

@app.route("/", methods=["GET"])
def form():
    return render_template("form.html")

@app.route("/submit", methods=["POST"])
def submit():
    data = {
        k: (request.form.get(k) or "").strip()
        for k in ["requirements_id", "date", "description", "spearhead", "stakeholder"]
    }

    if not all(data.values()):
        return "All fields are required.", 400

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            INSERT INTO requirements
            (requirements_id, date, description, spearhead, stakeholder, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (*data.values(), datetime.utcnow().isoformat())
        )

    return redirect(url_for("sheet"))

@app.route("/sheet", methods=["GET"])
def sheet():
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            """
            SELECT id, requirements_id, date, description, spearhead, stakeholder
            FROM requirements
            ORDER BY id DESC
            """
        ).fetchall()

    return render_template("sheet.html", rows=rows)

if __name__ == "__main__":
    # Flask 3.x compatibility: initialize explicitly (no lifecycle decorators)
    init_db()
    app.run(debug=True)
